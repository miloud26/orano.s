
import React from 'react';

const Team: React.FC = () => {
  const members = [
    {
      name: "Hamza Ouanzigui",
      title: "Creative & Copywriting",
      img: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=300"
    },
    {
      name: "Sohaib Gouaalla",
      title: "Founder & CEO",
      img: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=300"
    },
    {
      name: "Rafik Elmaknassi",
      title: "Marketing Chief",
      img: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&q=80&w=300"
    }
  ];

  return (
    <section className="py-16 md:py-24 bg-gray-50 px-4 sm:px-10 md:px-20">
      <div className="container mx-auto">
        {/* Team Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-10 mb-16 md:mb-28">
          {members.map((member, idx) => (
            <div key={idx} className="bg-white p-6 md:p-10 rounded-[30px] md:rounded-[40px] shadow-sm border border-gray-100 text-center flex flex-col items-center">
              <div className="w-24 h-24 md:w-32 md:h-32 mb-6 md:mb-8 rounded-full overflow-hidden shadow-inner ring-4 ring-gray-100">
                <img src={member.img} alt={member.name} className="w-full h-full object-cover" />
              </div>
              <h3 className="text-lg md:text-xl font-black text-[#0a0d1f] mb-1">{member.name}</h3>
              <p className="text-gray-400 text-xs md:text-sm font-medium uppercase tracking-wider">{member.title}</p>
            </div>
          ))}
        </div>

        {/* Meet the Team Description (Centered) */}
        <div className="max-w-4xl mx-auto text-center px-2">
          <h2 className="text-3xl md:text-6xl font-black text-[#0a0d1f] mb-6 md:mb-10 tracking-tight">قابل الفريق الأول</h2>
          <div className="space-y-4 md:space-y-6 text-[#475569] text-sm sm:text-lg md:text-xl leading-relaxed">
            <p>تم تأسيس الوكالة من طرف صهيب بعد خبرة أكثر من 4 سنوات في التجارة الإلكترونية الذي قضى السنوات الأخيرة في البحث عن أفضل الخبراء .</p>
            <p>ثقافة الوكالة ونظرتنا لك كشريك وليس فقط عميل ، يتوجب عليها البحث عن أفضل المواهب ، عندما يتعلق الأمر بالتوظيف . الفريق الذي تراه أمامك هو الأفضل في أورانوس.</p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Team;
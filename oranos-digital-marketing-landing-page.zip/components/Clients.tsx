
import React from 'react';

const Clients: React.FC = () => {
  return (
    <section className="py-12 md:py-24 bg-white px-4 sm:px-10 md:px-20">
      <div className="container mx-auto">
        <h2 className="text-2xl sm:text-3xl md:text-5xl font-black text-center mb-10 md:mb-20 text-[#0a0d1f] tracking-tight">عملاء وضعوا ثقتهم في وكالتنا</h2>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-8 md:gap-16 items-center opacity-70">
          {[0, 1, 2, 3, 4, 5].map((idx) => (
            <div key={idx} className="flex justify-center grayscale hover:grayscale-0 transition-all duration-300 transform hover:scale-105">
                <img 
                  src={`https://picsum.photos/seed/client${idx}/200/80?grayscale`} 
                  alt={`Client ${idx}`} 
                  className="max-h-8 sm:max-h-12 w-auto object-contain"
                />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Clients;
